import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import stat
import sys
import zipfile

base = Path('/tmp/semantic-calibration-884-replay')
plan = json.loads((base / 'plan.json').read_text())

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

if sys.argv[1] == 'extract':
    receipts = []
    for artifact in plan['artifacts']:
        name = artifact['name']
        original = base / 'zips' / (name + '.zip')
        assert original.stat().st_size == artifact['size_in_bytes']
        assert digest(original) == artifact['digest'].removeprefix('sha256:')
        destination = base / 'input' / name
        destination.mkdir(parents=True, exist_ok=False)
        with zipfile.ZipFile(original) as archive:
            members = archive.infolist()
            assert len({member.filename for member in members}) == len(members)
            assert sum(member.file_size for member in members) <= 256 * 1024**2
            for member in members:
                relative = PurePosixPath(member.filename)
                assert not relative.is_absolute() and '..' not in relative.parts
                assert not stat.S_ISLNK(member.external_attr >> 16)
                assert not member.flag_bits & 1
                if member.is_dir():
                    (destination / member.filename).mkdir(parents=True, exist_ok=True)
                else:
                    output = destination / member.filename
                    output.parent.mkdir(parents=True, exist_ok=True)
                    with archive.open(member) as source, output.open('xb') as target:
                        shutil.copyfileobj(source, target)
            receipts.append({'artifact': name, 'zip_sha256': digest(original),
                'members': len(members), 'expanded_bytes': sum(m.file_size for m in members),
                'crc_checked_by_complete_read': True})
    (base / 'destination-integrity.json').write_text(json.dumps(receipts, indent=2) + '\n')
    print(f'Extracted {len(receipts)} original compact ZIPs after destination SHA256 and complete CRC checks')
elif sys.argv[1] == 'seal-report':
    report = base / 'report'
    markdown = report / 'report.md'
    metadata = [json.loads(line) for line in markdown.read_text().splitlines()[:24]
        if line.startswith('{')]
    assert len(metadata) == 3
    original = report / 'report.json'
    summary = {'source_head': plan['source_head'], 'source_revision': plan['source_revision'],
        'source_tree': plan['source_tree'], 'original_run_id': plan['run_id'],
        'original_run_conclusion': 'failure', 'original_expected_workloads': 99,
        'replayed_expected_workloads': 102, 'new_SUT_measurements': 0,
        'control_validation': metadata[0], 'coverage': metadata[1],
        'benchmark_scope': metadata[2], 'report_json_sha256': digest(original),
        'report_json_size': original.stat().st_size, 'report_markdown_sha256': digest(markdown),
        'reporter_sha256': digest(Path('/workspace/target/semantic-approved-126952f6d048/release/bend2-perf'))}
    compressed = report / 'report.json.gz'
    with original.open('rb') as source, compressed.open('xb') as output:
        with gzip.GzipFile(filename='', fileobj=output, mode='wb', mtime=0) as target:
            shutil.copyfileobj(source, target)
    summary['compressed_json_sha256'] = digest(compressed)
    summary['compressed_json_size'] = compressed.stat().st_size
    (report / 'replay-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))
else:
    raise SystemExit('expected extract or seal-report')
